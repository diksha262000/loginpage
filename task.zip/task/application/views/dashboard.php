
<h1>hello</h1>

<form method="post" action="<?php echo base_url('AuthController')?>"></form>
<a href="<?php echo base_url() ?>xyz">logout </a>