
<?php


class AuthModel extends CI_Model{




    public function insert_item($table,$response)
    {    
        
        return $this->db->insert($table, $response);
    }
    
    public function insert_itemdynamic($table,$response)
    {    
        
        return $this->db->insert($table, $response);
    }
    public function userLogin($response){ 

        $this->db->select('*');
        $this->db->from('user');

        $this->db->where($response);
        $query = $this->db->get();
        return $query->row_array();
    }
    public function getCountry(){ 

        $this->db->select('*');
        $this->db->from('countries');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function getState($country_id){ 

        $this->db->select('*');
        $this->db->from('states');
        $this->db->where('country_id',$country_id);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function getCity($state_id){ 

        $this->db->select('*');
        $this->db->from('cities');
        $this->db->where('state_id',$state_id);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function showData()
    {
        $this->db->select('userid, countryName,stateName,cityName');
        $this->db->from('dynamic');
        $this->db->join('countries', 'dynamic.answerid = credentials.cid', 'outer');
        $this->db->join('states', 'tblanswers.answerid = credentials.cid', 'outer');
        $this->db->join('cities', 'tblanswers.answerid = credentials.cid', 'outer');
        $this->db->where('state_id',$state_id);
        $query = $this->db->get();
        return $query->result_array();
    }

}
?>