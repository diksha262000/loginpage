 <!DOCTYPE html>
 <html lang="en">
 <head>
   
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js" ></script>
    <title>Document</title>
 </head>
 <body>
 <h1>hello <span class ="h1" ></span> </h1>

<a href="<?php echo base_url() ?>xyz">logout </a>
    
<h1 class="text-center mt-3">Dynamic Dependency </h1>
    <div class="container mt-5">
         <div class="row">
             <div class="col-md-4">
                <form class="studentInfoForm" method="post"  enctype="multipart/form-data">
                    <div class="form-group">
                      
                      <input type="hidden" name="userid" id="userid">  
                    </div>

                    <div form-group>
                    <label for="country">Country </label>
                    <select name="country" id="country" class="form-select" onchange="getState(this.value)">
                    <option value="">Select Country</option>
                
                    </select>
                    </div>
                          
                    <div form-group>
                    <label for="state">State </label>
                    <select name="state" id="state" class="form-select" onchange="getCity(this.value)" >
                        <option value="">Select State</option>
                    </select>
                    </div>

                    <div form-group>
                    <label for="city">City </label>
                    <select name="city" id="city" class="form-select">
                        <option value="">Select City</option>
                    </select>
                    </div>

                    <div class="form-group">
                      <label for="pincode">Pincode</label>
                      <input type="text" name="pincode" id="pincode" class="form-control">
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary mt-2" id="submitBtn">Submit</button>
                    </div>
                </form>
            </div>
               <!-- Student Data Show -->
           <div class="col-md-8">
                <h3>Student Information</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <tr>
                                    <th>S.No.</th> 
                                    
                                   
                                    <th>Country</th>
                                    <th>State</th> 
                                    <th>City</th> 
                                    <th>Pincode</th> 
                                    <th>Action</th> 
                                </tr>
                            </tr>
                        </thead>
                        <tbody id="studentInfo">

                        </tbody>
                    </table>
                </div>
           </div>
        </div>
    </div>
 </body>
 </html>

<script>
       getName();
     function getName() {
                     $.ajax({
                            url: "<?php echo base_url() ?>dashboardget",
                            type: 'POST',
                            dataType: 'json',
                           // processData: false,
                            //contentType: false,
                           // data: new FormData($('.signupForm')[0]),
                            success: function(response) {
                               //console.log(response.status);
                                if(response.status == 200){
                                    $('.h1').html(response.name);
                                   // $('.signupForm')[0].reset();
                                    
                                  
                                }
                                else{
                                    alert(response.massage);
                                }
                            }
                     });
              }
              $('.studentInfoForm').validate({
            rules: {
    
                country: {
                    required: true,
                },
                state: {
                    required: true,
                    // remote: {
                    //     url: '<?php echo base_url() ?>validateEmail',
                    //     type: 'POST',
                    //     data: {
                    //         'email': function() {
                    //             return $('#email').val();
                    //         }
                            
                    //     },
                    // },
                },
                city: {
                    required: true,
                },
                pincode: {
                    required: true,
                },
            },
            messages: {
                country: {
                    required: "Please Country Name ",
                },
                
                state: {
                    required: "Please enter state name",
                   // remote: "  Already Exist so Please again enter Email",

                },
                city: {
                    required:  "Please enter state name",
                },
                pincode: {
                    required:  "Please enter pincode",
                },
            },
    
        submitHandler: function(form) {
                     $.ajax({
                            url: "<?php echo base_url() ?>dynamic",
                            type: 'POST',
                            dataType: 'json',
                            processData: false,
                            contentType: false,
                            data: new FormData($('.studentInfoForm')[0]),
                            success: function(response) {
                               //console.log(response.status);
                                if(response.status == 200){
                                    $('#submitbtn').html('Submit');
                                    $('.studentInfoForm')[0].reset();
                                    
                                  
                                }
                                else{
                                    alert(response.massage);
                                }
                            }
                     });
              }
       }); 
       
     showData();
   function showData(){
        $.ajax({
            url:"getInfo.php",
            type:"get",
            dataType:"json",
            success:function(response){
                var main_content ='';
                if(response.studentData.length>0){
                    $.each(response.studentData, function(index,row){
                        main_content+=
                        `<tr>
                             <td>`+(++index)+`</td>
                             <td>`+row.countryName+`</td>
                             <td>`+row.stateName+`</td>
                             <td>`+row.cityName+`</td>
                             <td>`+row.pincode+`</td>
                        <td>
                        <button type="button" onclick = "setStudentInfo(`+row.userid+`);" class = "btn btn-info me-2">Edit</button>
                        <button type = "button" onclick="deleteinfo(`+row.userid+`); "class="btn btn-warning">Delete</button>
                        </td>
                        </tr>`; 
                    })
                }else{
                    main_content = `No Data Found`
                }
                $('#studentInfo').html(main_content);
            }
        });  
    }  
       getCountry();
       function getCountry(countryId = '') {
              $.ajax({
                     url: "<?php echo base_url() ?>getCountry",
                     type: "get",
                     //cache: false,
                     dataType: 'json',
                     data: {
                            action: 'country'
                     },
                     success: function(response) {
                            countryHtml = '<option value="">Select Country</option>'
                            if (response.length > 0) {
                                   $.each(response, function(index, value) {
                                          var select = '';
                                          if (countryId != '' && countryId == value.id) {
                                                 select = 'selected';
                                          }
                                          countryHtml += `<option ` + select + ` value="` + value.id + `">` + value.name + `</option>`;
                                   });
                            }
                            $('#country').html(countryHtml);
                     }
              });
       }
      // getState();
       function getState(country_id, stateId) {
              $.ajax({
                     url: "<?php echo base_url() ?>getState",
                     type: "get",
                    // cache: false,
                     dataType: 'json',
                     data: {
                        country_id: country_id,
                            action: 'state'
                     },
                     success: function(response) {
                            stateHtml = '<option value="">Select State</option>'
                            if (response.state.length > 0) {
                                   $.each(response.state, function(index, value) {
                                          var abc = '';
                                          if (stateId != '' && stateId == value.id) {
                                                 abc = 'selected';
                                          }
                                          stateHtml += `<option ` + abc + ` value="` + value.id + `">` + value.name + `</option>`;
                                   });
                            }
                            $('#state').html(stateHtml);
                     }
              });
       }
 
      // getCity();
   function getCity(state_id, cityId) {
              $.ajax({
                     url:  "<?php echo base_url() ?>getCity",
                     type: "get",
                     //cache: false,
                     dataType: 'json',
                     data: {
                            state_id: state_id,
                            action: 'city'
                     },
                     success: function(response) {
                            cityHtml = '<option value="">Select City</option>'
                            if (response.city.length > 0) {
                                   $.each(response.city, function(index, value) {
                                          var select = '';
                                          if (cityId != '' && cityId == value.id) {

                                                 select = 'selected';
                                          }
                                          cityHtml += `<option ` + select + ` value="` + value.id + `">` + value.name + `</option>`;
                                   });
                            }
                            $('#city').html(cityHtml);
                     }
              });
       } 
</script>