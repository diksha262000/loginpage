<?php
defined('BASEPATH') OR exit('No direct script access allowed');  
  
class Userdashboard extends CI_Controller {
  public function __construct() {
    parent::__construct(); 


    $this->load->library('form_validation');
    $this->load->library('session');
    $this->load->model('AuthModel');

 }

 public function dashboard()
 {
    if($this->session->userdata('userid') !=""){
    $this->load->view('dashboard');  
     }else{
    redirect(base_url('AuthController'));
  }
}
public function dashboardget() 
   {
      
       $response = array(
           'userid' => $this->session->userdata('userid'),
      
       );
       $this->load->model('AuthModel');
      $result = $this->AuthModel->userLogin($response);
      //print_r($result);die;
       if($result){
            $name=$result['name'];
           $massage = 'Inserted Successfully';
           $status=200;
           
       }
       else{
        $name=   'not failed';
           $massage = 'Faild';
           $status = 400;
       }
       $response['name'] = $name; 
    $response['massage'] = $massage; 
    $response['status'] = $status; 
    echo json_encode($response);
   }
  

   public function getCountry(){
      // (isset($_GET['action']) && $_GET['action'] == 'studentCountry') {

  // Fetch state name base on country id
 
  $response = $this->AuthModel->getCountry();
   if($response)
   {
    $massage = 'Country Data';
    $status=200; 
  }
   else 
  {
      $response['massage'] = 'No Found';
      $response['status'] = '400';
      //$response['response'] = '';
  }
  
  echo json_encode($response);
}
   
public function getState(){
  // (isset($_GET['action']) && $_GET['action'] == 'studentCountry') {

// Fetch state name base on country id
$country_id = $this->input->get('country_id');
 if($country_id){
  $response['state']= $this->AuthModel->getState($country_id);
 
//$response = $this->AuthModel->getState($id);
//$result = $this->AuthModel->getState($response);
// print_r($result);

if($response)
{
   $massage = 'state Data';
     $status=200; 
}
else 
{
  $response['massage'] = 'No Found';
  $response['status'] = '400';
  //$response['response'] = '';
}

echo json_encode($response);
}
}

public function getCity(){
  
$state_id = $this->input->get('state_id');
 if($state_id){
  $response['city']= $this->AuthModel->getCity($state_id);
 if($response)
{
$massage = 'city Data';
$status=200; 
}
else 
{
  $response['massage'] = 'No Found';
  $response['status'] = '400';
  //$response['response'] = '';
}
 
echo json_encode($response);
}
}

public function showData()
{
   $result = $this->AuthModel->showData();
   $response['studentData'] = $  $result; 
   echo json_encode($response);
 }
}

  ?>