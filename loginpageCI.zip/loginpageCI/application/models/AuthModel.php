<?php
     
    class AuthModel extends CI_Model
    {
        
        public function insert_item($table,$data)
        {
            return $this->db->insert($table,$data);
        }
       
        public function userLogin($data)
        {
            $this->db->select('*');
            $this->db->from('user');
           $this->db->where($data);
          $query = $this->db->get();
            return $query->row_array();
        } 
    
        public function userNamecheck($data){
            $this->db->select('*');
            $this->db->from('user');
            $this->db->where($data);
            $query = $this->db->get();
            return $query->row_array();
        }
        
        public function userEmailcheck($data)
        {
            $this->db->select('*');
            $this->db->from('user');
            $this->db->where($data);
            $query = $this->db->get();
            return $query->row_array();
        }
        public function getDataId($userid)
    {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('userid',$userid);

        $query = $this->db->get();
       
        return $query->row_array();
    }
   
       
     public function updateProfile($data,$userid)
     {
       
        $this->db->where('userid',$userid);
        $this->db->update('user',$data);
        
    }
    public function change($userid)
    {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('userid', $userid);
        
        $query = $this->db->get();
            //print_r($query);
        return $query->row_array();
    }

    //updatePassword
    public function updatePass($userid,$new)
    {
        //$this->db->select('userPassword');
        
        $this->db->where('userid',$userid);
        
        return $this->db->update('user',$new);
    } 

}
?>

    
