<?php  
defined('BASEPATH') OR exit('No direct script access allowed');  
  
class AuthController extends CI_Controller { 
    public $Signup;

    
 
    public function __construct() {
       parent::__construct(); 
 
 
       $this->load->library('form_validation');
       $this->load->library('session');
       $this->load->model('AuthModel');

    }
 
    public function index()  
    {  
        
                $this->load->view('login');  
            
    }  
  
    public function registration()  
    {  
        $this->load->view('registration');  
    } 
    public function editProfile()  
    {  
        $this->load->view('editProfile');  
    } 
    public function dashboard()  
    {  
        $this->load->view('dashboard');  
    } 
    public function changePassword()  
    {  
        $this->load->view('changePassword');  
    } 

    function userNamecheck(){
        $data =array( 
            'userName'=>$this->input->post('userName'));
        $response = $this->AuthModel->userNamecheck($data);
        if($response > 0){
                echo 'false';
        }else{
             echo 'true';
        }
    
    }

     public function userEmailcheck()
    {
        $data =array( 
            'userEmail'=>$this->input->post('userEmail'));
        $response = $this->AuthModel->userEmailcheck($data);
        if($response > 0){
                echo 'false';
        }else{
             echo 'true';
        }
    }
}
?>