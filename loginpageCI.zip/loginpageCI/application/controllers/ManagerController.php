<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH.'libraries/REST_Controller.php';

class ManagerController extends REST_Controller {



	public function __construct() {
       parent::__construct(); 
     $this->load->model('AuthModel');
     $this->load->library('Authorization_Token');
     $this->load->library('session');
      $this->load->helpers('tokan');
      $this->load->library('form_validation');

    }
 
	public function userSignup_post()
	{
        
        $img = $_FILES["userProfilePic"]['tmp_name'];
        $filename = $_FILES["userProfilePic"]["name"];
        $file_ext = pathinfo($filename, PATHINFO_EXTENSION);

        $unique = md5(date('ymdHis')) . rand(11111, 999999);
        $name = $unique . '.' . $file_ext;
        move_uploaded_file($img, "uploadedImage/$name");

        $image = "uploadedImage/$name";
      //  print_r($image); 
    
    //print_r($_POST);die;
		$data = array(
            'userName' => $this->input->post('userName'),
            'userFullName' => $this->input->post('userFullName'),
            'userEmail' => $this->input->post('userEmail'),
            'userPassword' => $this->input->post('userPassword'),
            'userAddress' => $this->input->post('userAddress'),
            'userState' => $this->input->post('userState'),
            'userCity' => $this->input->post('userCity'),
            'userProfilePic' => $image,
            'gender' => $this->input->post('gender'),
		);

		    $result=$this->AuthModel->insert_item('user', $data);
        if($result){
        $this->response(array("message" => "Message successfuly" , "status" =>200 ), REST_Controller::HTTP_OK);
    }else{
        $this->response(array("message" => "failed" , "status" =>400), REST_Controller::HTTP_BAD_REQUEST);
    }
}
public function userLogin_post()
	{
    //print_r($_POST);die;
		$data = array(
            
            'userEmail' => $this->input->post('userEmail'),
            'userPassword' => $this->input->post('userPassword'),
		);
   
    // print_r($data);
		    $result = $this->AuthModel->userLogin($data);
      if($result){
            $tokenData['id'] =  $result['userid'];
            $tokenData['email'] = $result['userEmail'];
            $tokenData['role'] =  'user';
            $encode= $this->authorization_token->generateToken($tokenData);
             $this->session->set_userdata('token' , $encode);
             // print_r($encode); die;

      
        $this->response(array("message" => "Message successfuly","status"=>"200"), REST_Controller::HTTP_OK);
    }else{
        $this->response(array("message" => "failed" ), REST_Controller::HTTP_BAD_REQUEST);
    }
  }
public function getDataId_get()  
{  
  $headers = $this->input->request_headers();
  // print_r($headers);die();
  $headers= verifiedToken($headers);
  //if ($headers) {
    $userid = $headers['id'];
    $result = $this->AuthModel->getDataId($userid);
    if(!$result="")
  {
    $this->response(array("message" => "Success", 'user' => $result), REST_Controller::HTTP_OK);
  }
  else{
    $this->response(array("message" => "Failed", 'user' => (object)array()), REST_Controller::HTTP_BAD_REQUEST);
  }
}  

public function getProfile_get()
{
  $headers = $this->input->request_headers();
  // print_r($headers);die();
  $headers= verifiedToken($headers);
  if ($headers) {
  ///  API CODE   /////
  $userid = $headers['id'];
  $result = $this->AuthModel->getDataId($userid);
  
  $this->response(array("message" => "Success", 'user' => $result), REST_Controller::HTTP_OK);
  }else{
  $this->response(array("message" => 'Invalid Token'), REST_Controller::HTTP_BAD_REQUEST);
   }
 }
           //             <!-- UPDATE PROFILE  -->
         public function updateProfile_post()
	{
    $headers = $this->input->request_headers();
    //print_r($headers);die;
    $headers= verifiedToken($headers);
   // print_r($headers);
        $img = $_FILES["userProfilePic"]['tmp_name'];
        $filename = $_FILES["userProfilePic"]["name"];
        $file_ext = pathinfo($filename, PATHINFO_EXTENSION);

        $unique = md5(date('ymdHis')) . rand(11111, 999999);
        $name = $unique . '.' . $file_ext;
        move_uploaded_file($img, "uploadedImage/$name");

        $image = "uploadedImage/$name";
    
    //print_r($_POST);die;
    $userid = $this->input->post('userid');
		$data = array(
            'userName' => $this->input->post('userName'),
            'userFullName' => $this->input->post('userFullName'),
            'userEmail' => $this->input->post('userEmail'),
            'userPassword' => $this->input->post('userPassword'),
            'userAddress' => $this->input->post('userAddress'),
            'userState' => $this->input->post('userState'),
            'userCity' => $this->input->post('userCity'),
            'userProfilePic' => $image,
            'gender' => $this->input->post('gender'),
		);

            //print_r($data);die;
            if ($headers) {
                
  ///  API CODE   /////
 $userid = $headers['id'];
   $userid = $this->input->post('userid');
   //print_r($userid);die;
		    $result=$this->AuthModel->updateProfile($data,$userid);
        if(!$result=""){
        $this->response(array("message" => "Message successfuly" ,'user'=>$result), REST_Controller::HTTP_OK);
    }else{
        $this->response(array("message" => "failed" , 'user' => (object)array()), REST_Controller::HTTP_BAD_REQUEST);
    }
  }
  }
 
  public function changepassword_post(){
    $headers = $this->input->request_headers();
    $headers= verifiedToken($headers);
    $userid = $headers['id'];
   // print_r($userid);
    $data= $this->AuthModel->change($userid);
    $response=$this->input->post('userPassword');
    //print_r($data);die;
    $new = array('userPassword'=> $this->input->post('newPassword'));
  // print_r($data['userPassword']==$response);die;
    if(($response==$data['userPassword'])){
        $result=$this->AuthModel->updatepass($userid, $new);
    }
    else{
        echo " password Not match!";
    }
}
}

?>