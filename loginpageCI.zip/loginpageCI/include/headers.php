<!doctype html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta http-equiv="Content-Language" content="en">
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <title>Dollop Quiz</title>
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no">
   <!-- Disable tap highlight on IE -->
   <meta name="msapplication-tap-highlight" content="no">

   <!-- Favicon -->
   <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/admin/images/favicon.svg" type="image/x-icon">

   <!-- ///Material icon/// -->
   <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

   <!-- /// Style CSS /// -->
   <link href="<?php echo base_url(); ?>assets/admin/css/style.css" rel="stylesheet">

   <!-- /// Custom Style ///-->
   <link href="<?php echo base_url(); ?>assets/admin/css/custom_style.css" rel="stylesheet">

   <!-- /// All Font Icons ///-->
   <link href="<?php echo base_url(); ?>assets/admin/css/all_fonts_type.css" rel="stylesheet">
   <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/css/iziToast.min.css">
 
   <script type="text/javascript" src="<?php echo base_url(); ?>assets/admin/js/main.js"></script>

   <script src="<?php echo base_url(); ?>assets/admin/js/jquery.min.js"></script>
   <script src="<?php echo base_url(); ?>assets/admin/js/jquery.validate.min.js"></script>
   <script src="<?php echo base_url(); ?>assets/admin/js/validation.js"></script>
   <script src="<?php echo base_url(); ?>assets/admin/js/iziToast.min.js"></script>
   <script src="<?php echo base_url(); ?>assets/admin/js/sweetalert.min.js"></script>

   
</head>

<body>
</body>
